# Ahmed alkholy — مشروع تطبيق الدردشة

هذا مشروع ويب مبني بـ Vite وFirebase ومجهز لإنشاء تطبيق Android عبر Capacitor.

## مهم قبل الرفع إلى GitHub
- ارفع **محتويات هذا المجلد بعد فك الضغط** إلى جذر المستودع `Ahmed-alkholy` على الفرع `main`.
- احذف الملفات القديمة الخاصة ببناء Android اليدوي من جذر المستودع، خصوصاً:
  `AndroidManifest.xml`, `MainActivity.java`, `build.gradle`, `settings.gradle`, `gradle.properties`, `gradlew`, ومجلدات `app` أو `gradle` إن كانت من المحاولة السابقة.
- احذف ملف workflow القديم الموجود في جذر المستودع باسم `android-apk.yml` إن وجد.
- احتفظ بالمسارات كما هي، خصوصاً `.github/workflows/build-apk.yml` و`src/`.

## بناء APK
بعد رفع الملفات، افتح تبويب Actions وانتظر سير عمل **Build Ahmed alkholy APK**.
عند النجاح افتح التشغيل الأخضر، ثم من قسم Artifacts نزّل `Ahmed-alkholy-debug-apk.zip`.
فك ضغطه لتحصل على `app-debug.apk` وثبّته على هاتف Android.

## إعداد Firebase
المشروع يستخدم Firebase Authentication وCloud Firestore. فعّل Email/Password في Firebase Authentication، وانشر قواعد `firestore.rules` في Firestore.

لا يستخدم هذا الإصدار Firebase Storage أو رفع مرفقات. حالات التطبيق نصية، والرسائل نصية.
